<?php
// Basic mobile detection using user agent
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$isMobile = preg_match('/android|iphone|ipad|ipod|windows phone|blackberry|mobile/i', $userAgent);

// Redirect accordingly
if ($isMobile) {
    header('Location: mobilewallet.php', true, 302);
} else {
    header('Location: wallet.php', true, 302);
}
exit;
